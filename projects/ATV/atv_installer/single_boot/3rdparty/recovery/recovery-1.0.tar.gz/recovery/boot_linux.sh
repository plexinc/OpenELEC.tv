#!/bin/bash
#
echo "this is a boot_linux.sh script"
#
#
#mkdir -p /tmp/rootfs
#mount /dev/sda4 /tmp/rootfs
#kexec --load /tmp/rootfs/vmlinux --initrd=/tmp/rootfs/initrd/gz --command-line="root=/dev/sda4 initrd=initrd.gz"
#kexec -e
